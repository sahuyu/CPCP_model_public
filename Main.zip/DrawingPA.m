%% plotting
% output the figures of strain and stress / displacement and force in PA gel

addpath('linear_2D_FE_solver');
DataAndParameters;

flag = true;
% if true, draw strain/stress
% if false, draw displacement/force

LN = readmatrix('output/MaxLoopNumber.txt');
StepLength = 16;
Steps = LN/StepLength;
% dt = 75*StepLength/3600; %in hr

%% import data
Y0 = readmatrix('output/Y.0000.txt');
Z0 = readmatrix('output/Z.0000.txt');

Max_deformation = 0.9;%in um
Max_force = 0.12;%in uN
Max_strain = 2*10^-2;
Min_strain = -0.5*10^-2;
Max_stress = 25;%Pa
nbar = 64;
color_bar = turbo(nbar+1);

if ~isfolder('analysis')
    mkdir('analysis');
end

%% parameter for Linear 2D Finite Element Solver (Polyacrylamide gel)
Material{1}.Name='PA gel';
Material{1}.Type='Elastic Plane Stress';
Changing_ratio = 0.03*10^6;

Z_force = zeros(M,2); % force applied to PA gel
loop2stable = 3;

for t=0:1:Steps
    TargetTime = num2str(t*StepLength,'%04d');
    Y = readmatrix(['output/Y.', TargetTime , '.txt']);
    
    %Calculate the force applied on the PA gel
    Z = Z0;
    output = zeros(length(Z0),2);%[principle strain e1, vonMises stress se]
    for n=1:loop2stable
        for i=1:M
            temp_vector = Y(i,:) - Z(i,:);
            temp_dis = norm(temp_vector);
            if temp_dis>max_dis_col
                temp_vector = temp_vector.*max_dis_col./temp_dis;
                temp_dis = max_dis_col;
            end
            Z_force(i,:) = Changing_ratio.*Para_b.*(1-thickness/sqrt(thickness^2+temp_dis^2)).*temp_vector;
        end
        Nodes=Z0;%in um
        [Z_displacement, Triangles, output] = linear2D_FEA(Nodes, Z_force, Material, thickness_PA, true);
        Z = Z0 + Z_displacement;
    end
    
    if flag
        Strain = output(:,1);
        Stress = output(:,2);
        fig1=figure('Visible','off');
        fig1.Colormap=turbo;
        Lg = length(Strain);
        color_tri = color_bar(max(ones(Lg,1),min(ones(Lg,1).*nbar,ceil((Strain-Min_strain.*ones(Lg,1)).*nbar./(Max_strain-Min_strain))))+ones(Lg,1),:); %principle strain
        patch('Faces',Triangles,'Vertices',Z,'FaceVertexCData',color_tri,'FaceColor','flat','EdgeAlpha',0.05);
        colorbar('Ticks',[0,1],'TickLabels',{'0',num2str(Max_strain)});
        daspect([1 1 1]);
        axis([0, L, 0, W]);
        set(gcf,'color','white');
        set(gcf,'position',[100,100,1100,900]);
        A=getframe(gcf);
        if ~isfolder('analysis/PA_strain')
            mkdir('analysis/PA_strain');
        end
        filename = ['analysis/PA_strain/PA_strain_', TargetTime, '.png'];
        imwrite(A.cdata,filename);
        close all;
        
        fig2=figure('Visible','off');
        fig2.Colormap=turbo;
        color_tri = color_bar(min(ones(length(Stress),1).*nbar,ceil(Stress.*nbar./Max_stress))+ones(length(Stress),1),:); %vonMises stress
        patch('Faces',Triangles,'Vertices',Z,'FaceVertexCData',color_tri,'FaceColor','flat','EdgeAlpha',0.05);
        colorbar('Ticks',[0,1],'TickLabels',{'0',num2str(Max_stress)});
        daspect([1 1 1]);
        axis([0, L, 0, W]);
        set(gcf,'color','white');
        set(gcf,'position',[100,100,1100,900]);
        B=getframe(gcf);
        if ~isfolder('analysis/PA_stress')
            mkdir('analysis/PA_stress');
        end
        filename = ['analysis/PA_stress/PA_stress_', TargetTime, '.png'];
        imwrite(B.cdata,filename);
        close all;
    else
        for i=1:M
            temp_vector = Y(i,:) - Z(i,:);
            temp_dis = norm(temp_vector);
            Z_force(i,:) = Changing_ratio.*Para_b.*(1-thickness/sqrt(thickness^2+temp_dis^2)).*temp_vector.*10^-6;%in uN
        end
        % PA gel deformation
        fig1=figure('Visible','off');
        fig1.Colormap=turbo;
        color_tri = color_bar(min(ones(length(Z0),1).*nbar,ceil(dist2(Z,Z0).*nbar./Max_deformation))+ones(length(Z0),1),:); %accumulated displacement
    %     Triangles = delaunay(Z0(:,1),Z0(:,2));
        patch('Faces',Triangles,'Vertices',Z,'FaceVertexCData',color_tri,'FaceColor','interp','EdgeAlpha',0.05);
        colorbar('Ticks',[0,1],'TickLabels',{'0',num2str(Max_deformation)});
        daspect([1 1 1]);
        axis([0, L, 0, W]);
        set(gcf,'color','white');
        set(gcf,'position',[100,100,1100,900]);
        A=getframe(gcf);
        if ~isfolder('analysis/PA_deformation')
            mkdir('analysis/PA_deformation');
        end
        filename = ['analysis/PA_deformation/PA_deformed_', TargetTime, '.png'];
        imwrite(A.cdata,filename);
        close all;
    
        % PA gel remaining force
        fig2=figure('Visible','off');
        fig2.Colormap=turbo;
        color_tri(1:length(Z_force),:) = color_bar(min(ones(length(Z_force),1).*nbar,ceil(vecnorm(Z_force,2,2).*nbar./Max_force))+ones(length(Z_force),1),:); %remianing force
    %     Triangles = delaunay(Z0(:,1),Z0(:,2));
        patch('Faces',Triangles,'Vertices',Z,'FaceVertexCData',color_tri,'FaceColor','interp','EdgeAlpha',0.05);
        colorbar('Ticks',[0,1],'TickLabels',{'0',num2str(Max_force)});
        daspect([1 1 1]);
        axis([0, L, 0, W]);
        set(gcf,'color','white');
        set(gcf,'position',[100,100,1100,900]);
        B=getframe(gcf);
        if ~isfolder('analysis/PA_remainingForce')
            mkdir('analysis/PA_remainingForce');
        end
        filename = ['analysis/PA_remainingForce/PA_remainingForce_', TargetTime, '.png'];
        imwrite(B.cdata,filename);
        close all;
    end

end

close all;