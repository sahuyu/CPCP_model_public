%% initialization code
% used in MainLoop_ode.m

clear;

%% X:Coordinates of cells
% N*2 N: number of cells
filename = 'input/ini.X.txt';
X = readmatrix(filename);
N = length(X(:,1));

%% Y:Coordinates of collagen nodes
% M*2 M: number of collagen nodes
filename = 'input/ini.Y.txt';
Y = readmatrix(filename);
M = length(Y(:,1));

%% link_num & link_dis between collagen nodes
% E*2 E:number of links
% if y(i) is linked with y(j), link_num = i,j
% E*1 link_dis = initial length of spring between linked collagen nodes i and j
filename = 'input/ini.linknum.txt';
link_num = readmatrix(filename);
E = length(link_num(:,1));

filename = 'input/ini.linkdis.txt';
link_dis = readmatrix(filename);

%% triangles connectivity of the collagen fiber
% T*3 T:number of triangles
filename = 'input/ini.ele.txt';
ele = readmatrix(filename);
T = length(ele(:,1));

%% Cy:list of cell-col binding sites
% Cy: N*1 cell indicating the adhesion sites of each cell,
% expressed in indices of Y.
load('input/ini.Cy.mat','Cy');

%% Z:Coordinates of points in PA gel meshing
% O*2 O: number of points
filename = 'input/ini.Z.txt';
Z = readmatrix(filename);
O = length(Z(:,1));

%% link_com: compacted
% for link_num(f,:) = [i,j]
% if if y(i) is compacted with y(j), link_com(f)=1
link_com = false(E,1);

%% bindary condition
% rectangle
% length: L
% width: W
L = 300;
W = 300;

%% for DE, Collagen properties in 2D
%changing ratio of collagen's spring constant after compaction,△β>1
Para_db = 520;
%changing ratio of collagen's initial length after compaction,△l<1
Para_dl = 0.365;
%drag coefficient of collagen lattice (γ)
Para_y = 410.4;
%spring constant of collagen lattice (β)
Para_b = 1;
% β/γ, △β*β/γ, △l
Para = [Para_b/Para_y, Para_db*Para_b/Para_y, Para_dl];

%% cellular properties
% [migration factor, protrusion factor, contraction factor, binding coefficent(0,1], max activation factor(faM)]
Para_cell = [12, 1.2, 1.5, 0.99996, 10];
Para_binding_inactivated = 0.98;%bingding coefficent for inactivated cell
% weighted average factor of structure/density/contact/random driven cell orienting vector, respective
% structure: cells tend to migrate along the remodeled collagen fiber;
% density: cells tend to migrate outwards the clusters;
% contact: cells tend to migrate in the opposite direction, if too close to the adjecent cells
% random: generate by a single uniformly distributed random number [0,1];
Contribution_factor_cov = [4,2.4,2,1];
Target_cell_area = [30 50];
Max_cell_Peri2Area = 4;
Min_cell_Interval = [6 12];
Target_side_num = 8;%number of sides for cell (K)
Min_Cell_Division_Interval = 96;%time interval between cell division

% normal distribution
time=clock;
seed=round(sum(time(4:6))*sum(time(2:3))/10);
rng(seed);
initial_activation = [0.01,0.002];%[mean,SD]
variation = normrnd(initial_activation(1),initial_activation(2),N,1);
cell_binding = Para_cell(4).*ones(N,1);
cell_activation = Para_cell(5).*variation;%initial value for cell activation factor (fa)
[cell_migration, cell_protrusion, cell_contraction] = updateCellStatus(cell_activation, Para_cell, false);
cell_division = Min_Cell_Division_Interval.*ones(N,1);%<=0, ready to divide
isCellMigratingOut = false(N,1);

%% Collagen properties in 3D
%thickness of collagen layer, also the initial length of the spring that linked collagen and PA gel
thickness = 100;
% maximum effective collagen displacement (even if collagen dispacement is larger, the force will not further increase)
max_dis_col = 3;
filename = 'input/ThickCurve.txt';
ThicknCurve = readmatrix(filename);

%% Cell number (division)
filename = 'input/CellNumCurve.txt';
CellNumCurve = readmatrix(filename);

%% Parameter for differential equation solver
dt = 75;% step time in second
RelT = 1e-7;
AbsT = 1e-7;%*ones(2*M,1);

%% Initialization for the simulation
% loop number
LN = 48;%1152;
% proportion of ROI in total area
ROI_proportion = 0.9;
% should we adjust the cell contraction/migration/protrusion according to its area/perimeter
flag_o01 = true;
% stiffness sensing response time (≥2, united in loop)
StiffSenseResponseTime = 24;
% could cell activation affected adjacent cells?
flag_o02 = true;
% to what degree the cell activation factor been affected by adjacent cell?
ChangingRateOfFa_Adjacent = 1/72;
% fold change of cell activation factor after activated
ChangingFoldOfFa = 5;
% threshold for stiffness sensing value
Tsigma = 11*10^-4;
% changing ratio of cell activation factor per step, no matter activated or not
ChangingRateOfFa_overall = 1/50;
% add Calyculin A?
flag_o11 = false;
Para_CalyAcell = [36, 1.6, 1.5, 0.7, 10];
if flag_o11
    filename = 'input/CellNumCurve_CalyA.txt';
    CellNumCurve = readmatrix(filename);
end
% aCatKD cell?
flag_012 = false;
if flag_012
    Para_cell = [0.2, 0.4, 0.5, 0.996, 10];
    Contribution_factor_cov(2) = 0.6;
end

%% Parameter for Linear 2D Finite Element Solver (Polyacrylamide gel)
thickness_PA=50;          %Thickness of 2D FEM elements
Material{1}.E=1*10^3;   %Modulus of elasticity of mortar [1x10^3, 120x10^3]
Material{1}.v=0.5;        %Poisson ratio of mortar