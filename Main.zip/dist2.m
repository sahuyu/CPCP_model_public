% X,Y:[x1,y1; x2,y2; ... ;xn,yn] Nx2
% distance in 2D
function distance = dist2(X,Y)
    distance=sqrt(sum((X-Y).^2,2));
end

