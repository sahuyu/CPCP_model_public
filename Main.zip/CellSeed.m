%% initialization code
% seed ~100 cells as a cell cluster in the center of ROI

%% Y:Coordinates of collagen nodes
% M*2 M: number of collagen nodes
filename = 'input/ini.Y.txt';
Y = readmatrix(filename);
M = length(Y(:,1));

%% Seed cell (center of mass)
% density of cell (2D cells/100um^2)
density = 1.27;
center = [150 150];
radius = 50;
%number of cell N
N = ceil(density*pi*radius*radius/100);
min_cell = 7; %minimum distance between two cells
max_cell = 25; %maximum distance between two adjecent cells
X = zeros(N,2); %mass center of cells
CellStatus = zeros(N,1);%0:follower cell, 1:leader cell, 2:dispensive cell
u = 1;
% random distribution
seed=clock;
seed=round(sum(seed(4:6))*sum(seed(2:3))/10);
rng(seed);
temp = unifrnd(-1*radius,radius,40*N,2);
flag_c = 0;
for i=1:40*N
    if insideBindary(temp(i,:),[0,0],radius,1)
        flag = 1;
        if u>1
            for j=1:u
                if dist2(temp(i,:),X(j,:))<min_cell
                    flag = 0;
                end
            end
        end
    end
    
    if flag==1
        X(u,:) = temp(i,:);
        u = u+1;
        flag = 0;
    end
    if u>N
        break;
    end
end

X = X + [center(1).*ones(N,1), center(2).*ones(N,1)];

[V,C]=voronoin(X);

%% update the cell-col link
outline = convhull(X(:,1),X(:,2));
[in, on] = inpolygon(X(:,1),X(:,2),X(outline,1),X(outline,2));
Cy = cell(N,1);
minimum_leadCell_bindsite = 6;
for i=1:N
    if ~on(i) %follower cells
        C{i} = C{i}(C{i}>1);%if C{i}=1, V(C{i})=inf, else: inclosed cell boundary
        flag = inpolygon(V(C{i},1),V(C{i},2),X(outline,1),X(outline,2))';%1: inside the boundary of cluster
        Cy{i} = zeros(1,length(flag));
        for j=1:length(flag)
            positions = V(C{i}(j),:);
            if ~flag(j)
                distance = dist2(X(i,:),positions);
                if distance>min_cell
                    positions = X(i,:)+(min_cell/distance).*(positions-X(i,:));
                    V(C{i}(j),:) = positions;
                end
            end
            Cy{i}(j) = dsearchn(Y,positions)';
        end
    end
end
for i=1:N
    if on(i) %leading cells
        flag = C{i}>1;%if C{i}=1, V(C{i})=inf, else: inclosed cell boundary
%         f_in = inpolygon(V(C{i},1),V(C{i},2),X(outline,1),X(outline,2));%1: inside the boundary of cluster
%         flag = flag & f_in';
        positions = V(C{i}(flag),:);%nominated binding site on cell boundary
        indice_Y = dsearchn(Y,positions)';
        num_undetermined_site = minimum_leadCell_bindsite-sum(flag);
        if num_undetermined_site>0
            for j=1:num_undetermined_site
                angle = angle_anti(X(i,:),Y(indice_Y,:));
                angle_new = interpolation_radial(angle);
                positions = X(i,:)+[min_cell*cos(angle_new),min_cell*sin(angle_new)];
                indice_Y = [indice_Y, dsearchn(Y,positions)];
            end
        end
        %sort, anticlockwise
        angle = angle_anti(X(i,:),Y(indice_Y,:));
        temp = sortrows([angle,indice_Y'],1);
        Cy{i} = temp(:,2)';
    end
end

%% polt
subplot(1,2,1);
for i=1:length(C)
    patch(V(C{i},1),V(C{i},2),i);
    hold on
end
scatter(X(:,1),X(:,2),'k');
hold off
axis equal;

% update the cell center
for i=1:N
    X(i,:) = mean(Y(Cy{i},:));
end

subplot(1,2,2);
for i=1:length(C)
    patch(Y(Cy{i},1),Y(Cy{i},2),i);
    hold on
end
scatter(X(:,1),X(:,2),'k');
hold off
axis equal;

%% output
filename = 'input/ini.X.txt';
writematrix(X,filename);
filename = 'input/ini.Cy.mat';
save(filename,'Cy');