% used in MainLoop_ode.m

function [new_cell_activation, isactivated] = updateCellActivation(cell_activation, input_factor, Max, Cy, Yc, Threshold, proportion1, flag, proportion2)
%update the cell activation atatus based on the input_factor
%Max: 1x2 [max value for activated cell, max value for inactivated cell]
%flag: true- can be influenced bu adjacent cells
%proportion2: [0,1], proportion of influence from the adjacent cells
%Threshold: threshold for stiffness sensing value
%proportion1: [0,1], changing ratio of cell activation factor per step

% Curve_turning_points = [0, 0.3, 0.4, 0.9, 1; [0, 1, 2, 2.5, 3]*10^-4];
% Threshold = 11*10^-4;

N = length(cell_activation);
new_cell_activation = cell_activation;

mean_inputfactor = mean(input_factor);
if mean_inputfactor>Threshold
    isactivated = true;
    if max(cell_activation)<Max(1)
        for i=1:length(cell_activation)
            if input_factor(i)>Threshold
                new_cell_activation(i) = min(cell_activation(i)+Max(1)*proportion1, Max(1));
            end
        end
    end
else
    isactivated = false;
    if max(cell_activation)<Max(2)
        for i=1:length(cell_activation)
            if input_factor(i)>mean_inputfactor
                new_cell_activation(i) = min(cell_activation(i)+Max(2)*proportion1, Max(2));
            end
        end
    end
end

% for i=1:N
%     if flag
%         input_factor(i) = min(mean_inputfactor,input_factor(i));
%     end
%     location = find(Curve_turning_points(2,:)>input_factor(i));
%     if input_factor(i)<=0
%         new_cell_activation(i) = Curve_turning_points(1,1)*Max;
%     elseif isempty(location)
%         new_cell_activation(i) = Curve_turning_points(1,end)*Max;
%     else
%         s = min(location);
%         new_cell_activation(i) = Curve_turning_points(1,s-1)+(Curve_turning_points(1,s)-Curve_turning_points(1,s-1))*(input_factor(i)-Curve_turning_points(2,s-1))/(Curve_turning_points(2,s)-Curve_turning_points(2,s-1));
%         new_cell_activation(i) = new_cell_activation(i) * Max;
%     end
% 
%     new_cell_activation(i) = max(new_cell_activation(i), cell_activation(i));
% end

if flag %cell activation can be affected by adjecent cells
    list = [new_cell_activation, [1:N]'];
    list = sortrows(list);
    for i=1:N
        indices = list(i,2);
        adjecent_indices = find_adjacent_cell(indices, 1, Cy, Yc);
        if ~isempty(adjecent_indices)
            new_cell_activation(indices) = new_cell_activation(indices)*(1-proportion2) + max(new_cell_activation(adjecent_indices))*proportion2;
        end
    end
end

end

