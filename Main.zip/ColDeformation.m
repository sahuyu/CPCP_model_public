%% data amalysis and plotting
% collagen deformation

DataAndParameters;

LN = readmatrix('output/MaxLoopNumber.txt');
StepLength = 8;
Steps = LN/StepLength;
dt = 150*StepLength/3600; %in hr
min_frame = 12;
Y_col = cell(Steps+1,1);

%% Cell tracking
for t=0:1:Steps

    TargetTime = num2str(t*StepLength,'%04d');
    Y_col{t+1} = readmatrix(['output/Y.', TargetTime , '.txt']);

end

center = [150,150];

calc_speed = zeros(Steps,M); %in um/hr
calc_dis = zeros(Steps,M); %in um
calc_persis = zeros(Steps,M);

for nCol=1:M
    for nStep = 1:Steps
        calc_speed(nStep,nCol) = dist2(Y_col{nStep}(nCol,:),Y_col{nStep+1}(nCol,:))./dt;
        calc_dis(nStep,nCol) = dist2(Y_col{1}(nCol,:),Y_col{nStep+1}(nCol,:));
        if (nStep-1)>=(min_frame/2) && (Steps-nStep)>=(min_frame/2-1)
            temp_start_step = nStep-round(min_frame/2);
            temp_end_step = nStep+round(min_frame/2)-1;
            net_dis = dist2(Y_col{temp_start_step}(nCol,:),Y_col{temp_end_step}(nCol,:));
            cumulative_dis = 0;
            for i=1:temp_end_step-temp_start_step
                cumulative_dis = cumulative_dis + dist2(Y_col{temp_start_step+i-1}(nCol,:),Y_col{temp_start_step+i}(nCol,:));
            end
            calc_persis(nStep,nCol) = net_dis/cumulative_dis;
        end
    end
end

calc_speed(calc_speed==0) = NaN;
calc_dis(calc_dis==0) = NaN;
calc_persis(calc_persis==0) = NaN;
analysis_speed = [mean(calc_speed,2,'omitnan'),std(calc_speed,[],2,'omitnan'),sum(calc_speed>0,2)];
analysis_dis = [mean(calc_dis,2,'omitnan'),std(calc_dis,[],2,'omitnan'),sum(calc_dis>0,2)];
analysis_persis = [mean(calc_persis,2,'omitnan'),std(calc_persis,[],2,'omitnan'),sum(calc_persis>0,2)];
if ~isfolder('analysis')
    mkdir('analysis');
end
writematrix([analysis_speed,analysis_dis,analysis_persis],['analysis/Col_TData_Mean+SD.xlsx'],'Sheet','Data');


close all;
fig2=figure('Visible','off');
fig2.Colormap=jet;
numBin = 32; %(input('What is number of bins for colormap?'));
c = jet(numBin);
max_velocity = 1.5;

plot_x = zeros(M,Steps+1);
plot_y = zeros(M,Steps+1);
for nStep = 1:Steps+1
    for nCol = 1:M
        plot_x(nCol,nStep) = Y_col{nStep}(nCol,1);
        plot_y(nCol,nStep) = Y_col{nStep}(nCol,2);
    end
end
for nCol = 1:M
    b = ceil((mean(calc_speed(:,nCol),'omitnan')/max_velocity)*numBin);
    plot(plot_x(nCol,:), plot_y(nCol,:),'color',c(min(b,numBin),:),'LineWidth',1.0,'LineJoin','round');
    hold on;
end
hold off

axis equal;
axis([0, L, 0, W]);
dir = 'analysis/Col_Tracks_Realtime';
print('-painters',dir,'-dpdf'); %PDF
close(fig2);
