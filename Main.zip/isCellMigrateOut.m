%% find whether/which cell is moving out of ROI
% used in MainLoop_ode.m

function [flag] = isCellMigrateOut(X, W, L, percentage)
% percentage ∈ (0,1]

N = length(X(:,1));
flag = false(N,1);
a = [W, L].*(1-percentage)./2;
b = [W, L].*(1+percentage)./2;

for i=1:N
    flag(i) = ~insideBindary(X(i,:),a,b,2);
end

end

