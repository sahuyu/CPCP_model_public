%% find whether/which cell is ready to divide
% used in MainLoop_ode.m

function [indices, cell_division] = isCell2Divide(TargetCellNum, Cy, X, Y, isCellMigratingOut, cell_division, Min_cell_Interval)

N = length(Cy);
cell_area = zeros(N,1);
NewCellNum = TargetCellNum - N;

cell_division = cell_division - ones(N,1);
CellReady2Divide = find(cell_division<=0);
ReadyCellNum = length(CellReady2Divide);

if NewCellNum>0 && ReadyCellNum>0
    for i=1:N
        if isCellMigratingOut(i) || cell_division(i)>0
            % cell that migrated out or not ready to divide is not taken into consideration
            cell_area(i) = 0;
        else
            shape = alphaShape(Y(unique(Cy{i}),:));
            list_alpha = alphaSpectrum(shape);
            shape.Alpha = list_alpha(1);
            cell_area(i) = area(shape);
            
            distance_map = dist2(repmat(X(i,:),N,1),X);
            Adjacnet_cell_num = sum(distance_map>1e-3 & distance_map<Min_cell_Interval(2));
            cell_area(i) = cell_area(i)/(1+Adjacnet_cell_num*0.5);
        end
    end
    [~,sortInArea_index] = sortrows(cell_area,'descend');
    sortInArea_index = sortInArea_index(1:sum(cell_area>0));
    if isempty(sortInArea_index)
        indices = [];
    elseif length(sortInArea_index)<=NewCellNum
        indices = sortInArea_index;
    else
        indices = sortInArea_index(1:NewCellNum);
    end
else
    indices = [];
end

end

