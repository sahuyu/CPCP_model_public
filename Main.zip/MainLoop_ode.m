clear

addpath('linear_2D_FE_solver');

DataAndParameters;

if ~isfolder('output')
    mkdir('output');
end
logfile = fopen('output/log.txt','at');
fprintf(logfile,'\n--------------------\n');

%% Y:Coordinates of collagen nodes
% M.*2 M: number of collagen nodes
% [abscissa, ordinate]
%% data.link_num & data.link_dis between collagen nodes
% E*2 E:number of links
% if y(i) is linked with y(j), link_num = i,j
% E*1 link_dis = initial length of spring between linked collagen nodes i and j
%% data.link_com: compacted
% for link_num(f,:) = [i,j]
% if if y(i) is compacted with y(j), link_com(f)=1
%% X:Coordinates of cells
% N.*2 N: number of cells
% [abscissa, ordinate]

Z0 = Z; %initial position for PA gel mesh
Cy_normal = Cy; %temporarily used for ploting
Z_force = zeros(M,2); % force applied to PA gel

%% parameter for differential equation solver
data.M = M;
data.E = E;
data.link_num = link_num;
data.Para = Para;
data.h = thickness;
data.dis = max_dis_col;

% show starting time
fprintf(logfile, 'Main loop started at %s\n\n', datestr(now));
fprintf('Main loop started at %s\n\n', datestr(now));

%% parameter for Linear 2D Finite Element Solver (Polyacrylamide gel)
Material{1}.Name='PA gel';
Material{1}.Type='Elastic Plane Stress';
Changing_ratio = 0.03*10^6;

%% feedback from Col-PA to cells
abs_dy = 10^-3;
cell_stiff_sensing = zeros(N,1);
cell_stiff_sensing_history = zeros(N,StiffSenseResponseTime);
effective_stiffsensing_factor = zeros(N,1);

%% Output
LoopNumber = '0000';
writematrix(X,['output/X.', LoopNumber , '.txt']);
writematrix(Y,['output/Y.', LoopNumber , '.txt']);
writematrix(Z,['output/Z.', LoopNumber , '.txt']);
writematrix(link_com,['output/Com.', LoopNumber , '.txt']);
save(['output/Cy.', LoopNumber , '.mat'],'Cy');

fprintf(logfile,'Collagen:\nβ=%4f, γ=%4f, △β=%4f, △l=%4f, Thick=%d μm, Area:%d*%d in μm\n',Para_b,Para_y,Para_db,Para_dl,thickness,L,W);
fprintf(logfile,'PA gel:\nYoung''s module=%d Pa, Posiion ratio=%.2f, Thick=%d μm\n',Material{1}.E,Material{1}.v,thickness_PA);
fprintf(logfile,'Cells:\nMigration=%.2f, Protrusion=%.2f, Contraction=%.2f, Initial Activation=%.2f±%.2f (Maximum Value=%.2f) \n', Para_cell(1),Para_cell(2),Para_cell(3),initial_activation(1)*Para_cell(5),initial_activation(2)*Para_cell(5), Para_cell(5));
fprintf(logfile,'Binding coefficient=%f, Target cell area=[%d,%d], Max perimeter/area=%.2f\n',Para_cell(4),Target_cell_area(1),Target_cell_area(2),Max_cell_Peri2Area);
fprintf(logfile,'Weighted average factor of structure/density/contact/random driven cell orienting:[%.2f, %.2f, %.2f, %.2f]\n\n',Contribution_factor_cov(1),Contribution_factor_cov(2),Contribution_factor_cov(3),Contribution_factor_cov(4));
drawingCurve(Para_cell, 'output/');

thickMap = dataMapping(thickness, ThicknCurve, dt, LN);
cellNumMap = ceil(dataMapping(N, CellNumCurve, dt, LN));
Cy = refine_cellshape(Cy, Y, Target_side_num);
NewCellIndices = [];

for h=1:LN
    LoopNumber = num2str(h,'%04d');
    fprintf(logfile, 'step %d/%d started at %s\n', h, LN, datestr(now));
    %% Cellular behavior
    % cell division
    [Cy, N] = cell_dividing(Cy, NewCellIndices, Y, Target_side_num);
    if ~isempty(NewCellIndices)
        cell_activation = [cell_activation; cell_activation(NewCellIndices)];
        cell_binding = [cell_binding; cell_binding(NewCellIndices)];
        cell_contraction = [cell_contraction; cell_contraction(NewCellIndices)];
        cell_migration = [cell_migration; cell_migration(NewCellIndices)];
        cell_protrusion = [cell_protrusion; cell_protrusion(NewCellIndices)];
        cell_division = [cell_division; Min_Cell_Division_Interval.*ones(length(NewCellIndices),1)];
        for i=1:length(NewCellIndices)
            cell_division(NewCellIndices(i)) = Min_Cell_Division_Interval;
        end
        [X, ~] = updateCellCenter(X, Y, Cy, isCellMigratingOut);
        
        cell_stiff_sensing = [cell_stiff_sensing; cell_stiff_sensing(NewCellIndices)];
        effective_stiffsensing_factor = [effective_stiffsensing_factor; effective_stiffsensing_factor(NewCellIndices)];
        cell_stiff_sensing_history = [cell_stiff_sensing_history; cell_stiff_sensing_history(NewCellIndices,:)];
    end
    
    % remove the cells that migtated out
    isCellMigratingOut = isCellMigrateOut(X, W, L, ROI_proportion);
    for i=1:N
        if isCellMigratingOut(i)
            Cy{i} = [];
        end
    end
    Yc = list_transition(Cy,M);
    
    % update cell binding status
    cell_binding = updateCellAdhesion(Para_cell(4), Cy, Yc);
    % update the cell status
    [cell_orientation, cell_protrusion, cell_contraction] = updateCellStatus(cell_activation, Para_cell, flag_o01, Y, Cy, Target_cell_area, Max_cell_Peri2Area, isCellMigratingOut);
    
    % calculate the cell orienting vector (related to migration direction and speed)
    cell_orienting_vector = cell_orienting(X, Y, link_num, Min_cell_Interval, Contribution_factor_cov);
    
    % protrude & orient
    binding_sites = find(cellfun('isempty',Yc)==false);
    for i=1:length(binding_sites)
        %cells that linked with Y(binding_sites(i)),
        cell_list = Yc{binding_sites(i)};
        
        cell_protrude_vector = repmat(Y(binding_sites(i),:),length(cell_list),1) - X(cell_list,:);
        for j=1:length(cell_list)
            cell_protrude_vector(j,:) = cell_protrude_vector(j,:).*cell_protrusion(cell_list(j))./norm(cell_protrude_vector(j,:));
        end
        if length(cell_list)>1
            cell_protrude_vector = sum(cell_protrude_vector);
        end
        
        cell_orient_vector = cell_orienting_vector(cell_list,:);
        for j=1:length(cell_list)
            cell_orient_vector(j,:) = cell_orient_vector(j,:).*cell_orientation(cell_list(j));
        end
        if length(cell_list)>1
            cell_orient_vector = mean(cell_orient_vector);
        end
        
    
        %collagen nodes that linked with Y(binding_sites(i)),
        col_list = [link_num(link_num(:,1)==binding_sites(i),2);link_num(link_num(:,2)==binding_sites(i),1)];
    
        potential_coord = [Y(binding_sites(i),:); Y(col_list,:)];
        targeted_coord = Y(binding_sites(i),:) + cell_protrude_vector + cell_orient_vector;
        indices = dsearchn(potential_coord,targeted_coord);
        %if indices>1, update cell-col link; else, unchanged
        if indices>1
            Yc{binding_sites(i)} = intersect(cell_list,Yc{col_list(indices-1)});
            Yc{col_list(indices-1)} = unique([Yc{col_list(indices-1)},cell_list]);
        end
    end

    % update intercellular connection
    binding_sites = find(cellfun('isempty',Yc)==0);
    for i=1:length(binding_sites)
        cell_list = Yc{binding_sites(i)};
        if length(cell_list)>1
            for j=1:length(cell_list)
                p = rand(1);
                %if p>binding_factor, unbind the cell-col link
                if p > cell_binding(cell_list(j))
                    col_list = [link_num(link_num(:,1)==binding_sites(i),2);link_num(link_num(:,2)==binding_sites(i),1)];
                    indices = dsearchn(Y(col_list,:),Y(binding_sites(i),:));
                    if ~ismember(cell_list(j),Yc{col_list(indices)})
                        Yc{binding_sites(i)} = Yc{binding_sites(i)}(Yc{binding_sites(i)}~=cell_list(j));
                        Yc{col_list(indices)} = [Yc{col_list(indices)},cell_list(j)];
                    end
                end
            end
        end
    end

    % contract
    Y_laststep = Y;
    binding_sites = find(cellfun('isempty',Yc)==0);
    for i=1:length(binding_sites)
        %cells that linked with Y(binding_sites(i)),
        %weighed sum by contraction factor of each cells
        cell_list = Yc{binding_sites(i)};
        cell_contract_vector = X(cell_list,:) - repmat(Y(binding_sites(i),:),length(cell_list),1);
        for j=1:length(cell_list)
            cell_contract_vector(j,:) = cell_contract_vector(j,:).*cell_contraction(cell_list(j))./norm(cell_contract_vector(j,:));
        end
        if length(cell_list)>1
            cell_contract_vector = sum(cell_contract_vector);
        end
    
        Y(binding_sites(i),:) = Y(binding_sites(i),:) + cell_contract_vector;
    end
    Y_intermediary = Y;

    % update mapping table for cell-collagen adhesion sites
    Cy = list_transition(Yc,N);

    % update the cell center
    [X, Cy_normal] = updateCellCenter(X, Y, Cy, isCellMigratingOut);
    
    % draw cells and collagen to test whether the code working right
%     if h==1
%         filename = ['output/Col&Cell_', LoopNumber, '.png'];
%         Drawing();
%     end
    
    %% DE solving (collagen)
    % structure of x: 1~M, M+1~2M  [Y(:,1),Y(:,2)];
    x = [Y(:,1),Y(:,2)];
    data.link_dis = link_dis;
    data.link_com = link_com;
    data.Z = Z(1:M,:);
    
    x0 = x;
    tspan = [0 dt];
    options = odeset('RelTol',RelT,'AbsTol',AbsT);

    [t,x] = ode23(@(t,x) odefun(t,x,data), tspan, x0, options);
    
    Y = [x(length(t),1:M)',x(length(t),M+1:2*M)'];
    
    % update compacted collagen
    for j=1:E
        temp_vector = Y(link_num(j,1),:) - Y(link_num(j,2),:);
        temp_dis = norm(temp_vector);
        if (~link_com(j) && temp_dis <= Para(3)*link_dis(j))
            link_com(j) = true;
            link_dis(j) = Para(3)*link_dis(j);
        end
    end

    fprintf(logfile, 'DE solved at %s.\nRemodeled collagen = %d/%d\n', datestr(now), sum(link_com), E);
    
    %% FEA (Polyacrylamide gel)
    %Calculate the force applied on the PA gel
    for i=1:M
        temp_vector = Y(i,:) - Z(i,:);
        temp_dis = norm(temp_vector);
        if temp_dis>max_dis_col
            temp_vector = temp_vector.*max_dis_col./temp_dis;
            temp_dis = max_dis_col;
        end
        Z_force(i,:) = Changing_ratio.*Para_b.*(1-thickness/sqrt(thickness^2+temp_dis^2)).*temp_vector;
    end
    
    %Linear 2D FE solver
    Nodes=Z0;%.*10^-6 if unit in m
    [Z_displacement, Triangles, Strain] = linear2D_FEA(Nodes, Z_force, Material, thickness_PA, false);
    Z = Z0 + Z_displacement;%.*10^6 if unit in um
    
    fprintf(logfile, 'step %d/%d finished at %s\n', h, LN, datestr(now));
    fprintf('step %d/%d finished at %s\n', h, LN, datestr(now));
    
    %% stiff sensing of cells and feedback
    stiff_sensing_table = stiffSensingTable(abs_dy, Para, Cy, X, Y, Z, Z0, thickMap(h));
    for i=1:N
        cell_stiff_sensing(i,:) = mean(stiff_sensing_table{i});
    end
    writematrix(cell_stiff_sensing,['output/CellStiffSensing.',LoopNumber,'.txt']);
%     filename = ['output/Cell_StiffSensing_', LoopNumber, '.png'];
%     DrawingCell();
    
    cell_stiff_sensing_history = [cell_stiff_sensing_history(:,2:StiffSenseResponseTime),cell_stiff_sensing];
    effective_stiffsensing_factor = max([effective_stiffsensing_factor, mean(cell_stiff_sensing_history,2)],[],2);
    fprintf(logfile, 'Effective stiffsensing factor = %.4e\n\n', mean(effective_stiffsensing_factor));
    
    if h==192 && flag_o11 % add CalyA @4h
        %[migration, protrusion, contraction, binding(0,1], activation]
        Para_cell = Para_CalyAcell;
    end
    if h>=288
        %update cell activation status
        [cell_activation, isactivated] = updateCellActivation(cell_activation, effective_stiffsensing_factor, [Para_cell(5),Para_cell(5)/ChangingFoldOfFa], Cy, Yc, Tsigma, ChangingRateOfFa_overall, flag_o02, ChangingRateOfFa_Adjacent);
        if ~isactivated && h<384
            Para_cell(4) = Para_binding_inactivated;
        end
    end
    
    %% decide which cells to divide in the next loop
    [NewCellIndices, cell_division] = isCell2Divide(cellNumMap(h), Cy, X, Y, isCellMigratingOut, cell_division, Min_cell_Interval);
    
    %% output
    if mod(h,8)==0
        writematrix(X,['output/X.', LoopNumber , '.txt']);
    end
    if mod(h,16)==0
        writematrix(Y,['output/Y.', LoopNumber , '.txt']);
%         writematrix(Z,['output/Z.', LoopNumber , '.txt']);
        writematrix(link_com,['output/Com.', LoopNumber , '.txt']);
        save(['output/Cy.', LoopNumber , '.mat'],'Cy');
        rewrite('output/MaxLoopNumber.txt',h);
    end

end

fprintf(logfile, 'Main loop finished at %s\n\n', datestr(now));
fclose(logfile);
fprintf('\nMain loop finished at %s\n\n', datestr(now));

CellTracking
DrawingAll
DrawingPA