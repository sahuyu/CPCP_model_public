%% plotting
% output the cell/collagen and collagen defromation figures

DataAndParameters;

LN = readmatrix('output/MaxLoopNumber.txt');
StepLength = 16;
Steps = LN/StepLength;
dt = 75*StepLength/3600; %in hr
% X_cell = cell(Steps+1,1);
% Y_col = cell(Steps+1,1);

%% import data
X0 = readmatrix(['output/X.0000.txt']);
Y0 = readmatrix(['output/Y.0000.txt']);
% Z0 = readmatrix(['output/Z.0000.txt']);

Max_deformation = 35;
nbar = 64;
color_bar = turbo(nbar+1);

if ~isfolder('analysis')
    mkdir('analysis');
end

for t=0:1:Steps
    TargetTime = num2str(t*StepLength,'%04d');
    X = readmatrix(['output/X.', TargetTime , '.txt']);
    Y = readmatrix(['output/Y.', TargetTime , '.txt']);
    
    % collagen deformation
    fig1=figure('Visible','off');
    fig1.Colormap=turbo;
    color_tri = color_bar(min(ones(length(Y0),1).*nbar,ceil(dist2(Y,Y0).*nbar./Max_deformation))+ones(length(Y0),1),:); %accumulated displacement
    Triangles = delaunay(Y0(:,1),Y0(:,2));
    patch('Faces',Triangles,'Vertices',Y,'FaceVertexCData',color_tri,'FaceColor','interp','EdgeAlpha',0.05);
    colorbar('Ticks',[0,1],'TickLabels',{'0',num2str(Max_deformation)});
    daspect([1 1 1]);
    axis([0, L, 0, W]);
    set(gcf,'color','white');
    set(gcf,'position',[100,100,1100,900]);
    A=getframe(gcf);
    if ~isfolder('analysis/Col_deformation')
        mkdir('analysis/Col_deformation');
    end
    filename = ['analysis/Col_deformation/Col_deformed_', TargetTime, '.png'];
    imwrite(A.cdata,filename);
    
    close all;
    
    fig2=figure('Visible','off');
    patch('Faces',Triangles,'Vertices',Y,'EdgeColor',[0 1 1],'EdgeAlpha',0.3,'FaceColor','none');
    hold on
    load(['output/Cy.', TargetTime , '.mat'],'Cy');
    N = length(Cy);
    for i=1:N
        if ~isempty(Cy{i})
            shape = alphaShape(Y(unique(Cy{i}),:));
            list_alpha = alphaSpectrum(shape);
            shape.Alpha = list_alpha(1);
            indices = boundaryFacets(shape);
            Cy_normal = Cy{i}(1,indices(:,1));
            if t==0
                Cy_normal = Cy{i};
            end
            patch('Faces',Cy_normal,'Vertices',Y,'EdgeColor',[1 0.5 0],'FaceColor','none','LineWidth',1);
%             points = Y([Cy_normal(end),Cy_normal,Cy_normal(1)],:);
%             points = spcrv(points',3);% smooth cell outline
%             plot(points(1,:),points(2,:),'k-');
            hold on
        end
    end
    scatter(X(:,1),X(:,2),'k');
    hold off
    daspect([1 1 1]);
    axis([0, L, 0, W]);
    set(gcf,'color','white');
    set(gcf,'position',[100,100,1100,900]);
    A=getframe(gcf);
    if ~isfolder('analysis/Cell&Col')
        mkdir('analysis/Cell&Col');
    end
    filename = ['analysis/Cell&Col/Cell&Col_', TargetTime, '.png'];
    imwrite(A.cdata,filename);
    
    close all;
end

close all;