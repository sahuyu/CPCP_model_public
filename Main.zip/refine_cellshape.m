%% add more nodes to the cell if necessary
% used in MainLoop_ode.m

function [Cy] = refine_cellshape(Cy, Y, Target_side_num)

N = length(Cy);
M = length(Y(:,1));
Yc = list_transition(Cy,M);

for i=1:N
    cellNode_indices = unique(Cy{i});
    NodesNum2Add = Target_side_num - length(cellNode_indices);
    if NodesNum2Add>0 && length(cellNode_indices)>=3
        % if there are some shared segments, add new nodes on the middle of longest
        % segment, then the second longest, and so on;
        % if the number of shared segments is not enough, use the other segments on
        % the boundary of the cell;

        % determine that new nodes should be added on which segments
        shape = alphaShape(Y(cellNode_indices,:));
        list_alpha = alphaSpectrum(shape);
        if ~isempty(list_alpha)
            shape.Alpha = list_alpha(1)+1;
        end
        trangle_list = alphaTriangulation(shape);
        segment_list = [trangle_list(:,[1,2]);trangle_list(:,[2,3]);trangle_list(:,[1,3])];
        segment_list = sort(segment_list,2);
        segment_list = unique(segment_list,'row');
        estimatedBoundary_sl = sort(boundaryFacets(shape),2);
        whichCellisSegmentShared = cell(length(segment_list),1);
        for j=1:length(segment_list)
            Node1sharedwith = Yc{cellNode_indices(segment_list(j,1))};
            Node2sharedwith = Yc{cellNode_indices(segment_list(j,2))};
            SharedCellList = intersect(Node1sharedwith,Node2sharedwith);
            whichCellisSegmentShared{j} = SharedCellList(SharedCellList~=i);
        end
        segmentLength = dist2(Y(cellNode_indices(segment_list(:,1)),:),Y(cellNode_indices(segment_list(:,2)),:));

        sharedSegment_indices = find(cellfun('isempty',whichCellisSegmentShared)==false);
        prefer2add_sl_shared = [segment_list(sharedSegment_indices,:),segmentLength(sharedSegment_indices)];
        [prefer2add_sl_shared,index_table] = sortrows(prefer2add_sl_shared,3,'descend');
        prefer2add_sl_shared_2_whichCellisSegmentShared = sharedSegment_indices(index_table);
        num_of_shared_segment = length(sharedSegment_indices);

        unsharedSegment_indices = find(cellfun('isempty',whichCellisSegmentShared)==true);
        prefer2add_sl_unshared = [segment_list(unsharedSegment_indices,:),segmentLength(unsharedSegment_indices)];
        [~,ia,~] = intersect(prefer2add_sl_unshared(:,1:2),estimatedBoundary_sl,'rows');
        prefer2add_sl_unshared = prefer2add_sl_unshared(ia,:);
        prefer2add_sl_unshared = sortrows(prefer2add_sl_unshared,3,'descend');

        prefer2add_sl = [prefer2add_sl_shared(:,1:2);prefer2add_sl_unshared(:,1:2)];

        % add new nodes to target cell and the cells that share segments with it
        NodesNum2Add = min(NodesNum2Add,length(prefer2add_sl));
        Y_target = zeros(NodesNum2Add,2);
        for t=1:NodesNum2Add
            Y1 = Y(cellNode_indices(prefer2add_sl(t,1)),:);
            Y2 = Y(cellNode_indices(prefer2add_sl(t,2)),:);
            Y_target(t,:) = (Y1+Y2)./2;
        end
        new_Y_indices = dsearchn(Y,Y_target);
        Cy{i} = unique([Cy{i},new_Y_indices']);
        for t=1:NodesNum2Add
            Yc{new_Y_indices(t)} = unique([Yc{new_Y_indices(t)},i]);
            if t<=num_of_shared_segment
                OtherCellIndices = whichCellisSegmentShared{prefer2add_sl_shared_2_whichCellisSegmentShared(t)};
                Yc{new_Y_indices(t)} = unique([Yc{new_Y_indices(t)},OtherCellIndices]);
                for s=1:length(OtherCellIndices)
                    Cy{OtherCellIndices(s)} = unique([Cy{OtherCellIndices(s)},new_Y_indices(t)]);
                end
            end
        end
    end
end

end

