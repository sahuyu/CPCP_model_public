%% plotting, used for debugging

close all
LN = readmatrix('output/MaxLoopNumber.txt');
Mean = zeros(LN,1);
SD = zeros(LN,1);
for h=1:LN
    LoopNumber = num2str(h,'%04d');
    temp_cell_stiff_sensing = readmatrix(['output/CellStiffSensing.',LoopNumber,'.txt']);
    Mean(h) = mean(temp_cell_stiff_sensing,'omitnan');
    SD(h) = std(temp_cell_stiff_sensing,'omitnan');
end
errorbar(1:LN,Mean,SD);
set(gcf,'color','white');
set(gcf,'position',[100,100,1700,700]);
A=getframe(gcf);
if ~isfolder('analysis')
    mkdir('analysis');
end
filename = ['analysis/Cell_StiffSensing_Plot.png'];
imwrite(A.cdata,filename);
close all