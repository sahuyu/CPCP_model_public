% used in MainLoop_ode.m

function [dataMap] = dataMapping(Initial_Value, DataCurve, dt, LN)

dataMap = zeros(LN,1);
DataCurve(:,2) = DataCurve(:,2).*Initial_Value./DataCurve(1,2);
for i=1:LN
    t = i*dt/3600;
    location = find(DataCurve(:,1)>t);
    if t<=0
        dataMap(i) = DataCurve(1,2);
    elseif isempty(location)
        dataMap(i) = DataCurve(end,2);
    else
        s = min(location);
        dataMap(i) = DataCurve(s-1,2)+(DataCurve(s,2)-DataCurve(s-1,2))*(t-DataCurve(s-1,1))/(DataCurve(s,1)-DataCurve(s-1,1));
    end
end

end

