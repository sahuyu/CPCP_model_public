%% if all the nodes of one cell is shared by other cell/cells, its bingding factor is reset to 1
% used in MainLoop_ode.m

function [new_cell_binding] = updateCellAdhesion(binding_factor, Cy, Yc)

N = length(Cy);
num_shared_nodes = zeros(N,2);
new_cell_binding = binding_factor.*ones(N,1);

for i=1:N
    num_shared_nodes(i,2) = length(Cy{i});
    for j=1:num_shared_nodes(i,2)
        node_indice = Cy{i}(j);
        if length(Yc{node_indice})>1
            num_shared_nodes(i,1) = num_shared_nodes(i,1) + 1;
        end
    end
    new_cell_binding(i) = max(num_shared_nodes(i,1)/num_shared_nodes(i,2),binding_factor);
end


end

