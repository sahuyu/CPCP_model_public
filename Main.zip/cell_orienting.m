%% calculate the cell migration vector based on current collagen structure and cell distribution
% used in MainLoop_ode.m

function [cell_orienting_vector] = cell_orienting(X, Y, link_num, Min_cell_Interval, Contribution_factor_cov)

N = length(X(:,1));

cell_orienting_vector = zeros(N,2);
structure_drived_cov = cell(N,1);
density_drived_cov = zeros(N,2);
contact_drived_cov = zeros(N,2);
% weighted average factor of structure/density driven cell orienting vector, respective

% Refference to calculate the orientation tensor of collagen network
% Aghvami, M., V.H. Barocas and E.A. Sander, Multiscale mechanical simulations of cell compacted collagen gels. J Biomech Eng, 2013. 135(7): p. 71004.

for i=1:N
    % calculate the collagen structure drived cell trend vector
    link_list = find_adjacent_link(X(i,:),8,Y,link_num);
    omega_num = zeros(2,2);
    omega_den = 0;
    for j=1:length(link_list)
        s = link_num(j,1);
        t = link_num(j,2);
        dl = Y(s,:)-Y(t,:);
        abs_l = norm(dl);
        omega_num = omega_num + [dl(1)^2,dl(1)*dl(2);dl(1)*dl(2),dl(2)^2]./abs_l;
        omega_den = omega_den + abs_l;
    end
    if omega_den>0
        omega = omega_num./omega_den;
        [vector, lambda] = eig(omega);
        structure_drived_cov{i} = lambda*vector.*(lambda(2,2)-lambda(1,1));
    else
        structure_drived_cov{i} = [0,0;0,0];
    end
    % calculate the cell density drived cell trend vector
    for j=1:N
        dis_vector = X(i,:) - X(j,:);
        if i~=j
            density_drived_cov(i,:) = density_drived_cov(i,:) + dis_vector./sum(dis_vector.^2);
        end
    end
    % calculate the cell contact drived cell trend vector
    distance_map = dist2(repmat(X(i,:),N,1),X);
    index = find(distance_map>1e-3 & distance_map<Min_cell_Interval(2));
    if ~isempty(index)
        [~, indices] = sort(distance_map(index));
        index = index(indices);
        index = index(1:min(length(index),3));
        for j=1:length(index)
            vector = X(i,:) - X(index(j),:);
            factor = (Min_cell_Interval(2)/norm(vector)-1)*Min_cell_Interval(1)/(Min_cell_Interval(2)-Min_cell_Interval(1));
            contact_drived_cov(i,:) = contact_drived_cov(i,:) + vector.*factor./norm(vector);
            % following y=a/x+b, points(Min_cell_Interval(1),1),(Min_cell_Interval(2),0) on the curve
            % x: distance, y: factor
        end
    end
    
    % calculate the weighted averaged migration trend vector
    vector_s1 = structure_drived_cov{i}(1,:)*Contribution_factor_cov(1);
    vector_s2 = structure_drived_cov{i}(2,:)*Contribution_factor_cov(1);
    vector_d = density_drived_cov(i,:)*Contribution_factor_cov(2);
    vector_c = contact_drived_cov(i,:)*Contribution_factor_cov(3);
    vector_r = (rand(1,2)-[0.5 0.5])*Contribution_factor_cov(4);
    if dot(vector_s1,vector_d)<0
        vector_s1 = -1.*vector_s1;
    end
    if dot(vector_s2,vector_d)<0
        vector_s2 = -1.*vector_s2;
    end
    cell_orienting_vector(i,:) = vector_s1 + vector_s2 + vector_d + vector_c + vector_r;
    
%     plot([X(i,1)+vector_s1(1), X(i,1), X(i,1)+vector_s2(1)],[X(i,2)+vector_s1(2), X(i,2), X(i,2)+vector_s2(2)],'k');
%     plot([X(i,1), X(i,1)+vector_d(1)],[X(i,2), X(i,2)+vector_d(2)],'r');
%     plot([X(i,1), X(i,1)+cell_orienting_vector(i,1)],[X(i,2), X(i,2)+cell_orienting_vector(i,2)],'b.');
%     hold on
end
% hold off
% axis equal;

end

