% used in MainLoop_ode.m

function [cell_orientation, cell_protrusion, cell_contraction] = updateCellStatus(cell_activation, Para_cell, flag ,Y, Cy, TCA, MCP, isCellMigratingOut)
%TCA: target cell area [min, max]
%MCP: Max cell perimeter/area value

% percentage on Y axis; turning points of orientation on X axis;
Curve_turning_points_O = [0.03, 0.5, 0.9, 0.95, 1; 0, 1, 2, 8, 10];
% percentage on Y axis; turning points of protrusion on X axis;
Curve_turning_points_P = [0.1, 0.3, 0.95, 1; 0, 4, 8, 10];
% percentage on Y axis; turning points of contraction on X axis;
Curve_turning_points_C = [0.8, 0.85, 0.95, 1; 0, 4, 8, 10];

N = length(cell_activation);

cell_orientation = zeros(N,1);
for i=1:N
    location = find(Curve_turning_points_O(2,:)>cell_activation(i));
    if cell_activation(i)<=0
        cell_orientation(i) = Curve_turning_points_O(1,1)*Para_cell(1);
    elseif isempty(location)
        cell_orientation(i) = Curve_turning_points_O(1,end)*Para_cell(1);
    else
        s = min(location);
        cell_orientation(i) = Curve_turning_points_O(1,s-1)+(Curve_turning_points_O(1,s)-Curve_turning_points_O(1,s-1))*(cell_activation(i)-Curve_turning_points_O(2,s-1))/(Curve_turning_points_O(2,s)-Curve_turning_points_O(2,s-1));
        cell_orientation(i) = cell_orientation(i)*Para_cell(1);
    end
end

cell_protrusion = zeros(N,1);
for i=1:N
    location = find(Curve_turning_points_P(2,:)>cell_activation(i));
    if cell_activation(i)<=0
        cell_protrusion(i) = Curve_turning_points_P(1,1)*Para_cell(2);
    elseif isempty(location)
        cell_protrusion(i) = Curve_turning_points_P(1,end)*Para_cell(2);
    else
        s = min(location);
        cell_protrusion(i) = Curve_turning_points_P(1,s-1)+(Curve_turning_points_P(1,s)-Curve_turning_points_P(1,s-1))*(cell_activation(i)-Curve_turning_points_P(2,s-1))/(Curve_turning_points_P(2,s)-Curve_turning_points_P(2,s-1));
        cell_protrusion(i) = cell_protrusion(i)*Para_cell(2);
    end
end

cell_contraction = zeros(N,1);
for i=1:N
    location = find(Curve_turning_points_C(2,:)>cell_activation(i));
    if cell_activation(i)<=0
        cell_contraction(i) = Curve_turning_points_C(1,1)*Para_cell(3);
    elseif isempty(location)
        cell_contraction(i) = Curve_turning_points_C(1,end)*Para_cell(3);
    else
        s = min(location);
        cell_contraction(i) = Curve_turning_points_C(1,s-1)+(Curve_turning_points_C(1,s)-Curve_turning_points_C(1,s-1))*(cell_activation(i)-Curve_turning_points_C(2,s-1))/(Curve_turning_points_C(2,s)-Curve_turning_points_C(2,s-1));
        cell_contraction(i) = cell_contraction(i)*Para_cell(3);
    end
end

%adjust the cell contraction/protrusion according to its area/perimeter
if flag
    Area_range = [max(0,(4*TCA(1)-TCA(2))/3), TCA(1), TCA(2), (4*TCA(2)-TCA(1))/3];
    P2A_range = [5*MCP/6, 3*MCP/2];
    for i=1:N
        if ~isCellMigratingOut(i)
            %cell_area = polyarea(Y(Cy{i},1),Y(Cy{i},2));
            shape = alphaShape(Y(unique(Cy{i}),:));
            list_alpha = alphaSpectrum(shape);
            shape.Alpha = list_alpha(1);
            cell_area = area(shape);
            cell_peri2area = perimeter(shape)/cell_area;
            if cell_area<Area_range(1)
                cell_contraction(i) = 0;
            elseif cell_area<Area_range(2)
                cell_contraction(i) = cell_contraction(i)*(cell_area-Area_range(1))/(Area_range(2)-Area_range(1));
            end
            if cell_area>Area_range(4)
                cell_protrusion(i) = 0;
                cell_orientation(i) = 0;
            elseif cell_area>Area_range(3)
                cell_protrusion(i) = cell_protrusion(i)*(Area_range(4)-cell_area)/(Area_range(4)-Area_range(3));
                cell_orientation(i) = cell_orientation(i)*(Area_range(4)-cell_area)/(Area_range(4)-Area_range(3));
            end
            if cell_peri2area>P2A_range(2)
                cell_orientation(i) = cell_orientation(i)/2;
            elseif cell_peri2area>P2A_range(1)
                cell_orientation(i) = cell_orientation(i) - cell_orientation(i)*(cell_peri2area-P2A_range(1))/(P2A_range(2)-P2A_range(1))/2;
            end
        end
    end
end

end

