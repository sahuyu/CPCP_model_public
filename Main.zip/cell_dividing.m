%% divide the cells listed in "indices"

function [new_Cy, N] = cell_dividing(Cy, indices, Y, Target_side_num)

    N = length(Cy);
    M = length(Y(:,1));
    new_Cy = [Cy; cell(length(indices),1)];
    NewCell_1_indices = [];
    NewCell_2_indices = [];

    for i=1:length(indices)
        Yc = list_transition(new_Cy,M);
        cellNode_indices = unique(new_Cy{indices(i)});
        Yy = Y(cellNode_indices,:);
        shape = alphaShape(Yy);
        list_alpha = alphaSpectrum(shape);
        shape.Alpha = list_alpha(1)+1;
        estimatedBoundary_sl = boundaryFacets(shape);
        cellNode_onBoundary_indices = estimatedBoundary_sl(:,1);
        NumOfNodesOnB = length(cellNode_onBoundary_indices);
        % find the long axis of the cell
        center = mean(Yy);
        vectorOfNodes = Yy(cellNode_onBoundary_indices,:)-repmat(center,NumOfNodesOnB,1);
        longAxis_vector = sum(vectorOfNodes);
        projection_length = dot(vectorOfNodes, repmat(longAxis_vector,NumOfNodesOnB,1), 2);
        [~, Indices_1] = max(projection_length);
        [~, Indices_2] = min(projection_length);
        temp = [Indices_1, Indices_2];
        Indices_1 = min(temp);
        Indices_2 = max(temp);
        % divide cell into two parts based on the two nodes that on the opposite side of the cell
        % if unable to divide properly, add a new node
        if Indices_2-Indices_1==1
            % add on new nodes on the segment
            Segment2Cut_indices = cellNode_indices(cellNode_onBoundary_indices([Indices_1,Indices_2]));
            New_node = mean(Y(Segment2Cut_indices,:));
            New_node_indices = dsearchn(Y,New_node);
            Node1sharedwith = Yc{Segment2Cut_indices(1)};
            Node2sharedwith = Yc{Segment2Cut_indices(2)};
            whichCellisSegmentShared = intersect(Node1sharedwith,Node2sharedwith);
            for j=1:length(whichCellisSegmentShared)%if shared with other cells
                Cy{whichCellisSegmentShared(j)} = unique([Cy{whichCellisSegmentShared(j)},New_node_indices]);
            end
            % deal with the other side
            SharedIndices2 = floor((Indices_1+Indices_2+NumOfNodesOnB)/2);
            if SharedIndices2>NumOfNodesOnB
                SharedIndices2 = SharedIndices2 - NumOfNodesOnB;
                NewCell_1_indices = [New_node_indices, cellNode_indices(cellNode_onBoundary_indices([Indices_2:NumOfNodesOnB, 1:SharedIndices2]))];
                NewCell_2_indices = [cellNode_indices(cellNode_onBoundary_indices(SharedIndices2:Indices_1)), New_node_indices];
            else
                NewCell_1_indices = [New_node_indices, cellNode_indices(cellNode_onBoundary_indices(Indices_2:SharedIndices2))];
                NewCell_2_indices = [cellNode_indices(cellNode_onBoundary_indices([SharedIndices2:NumOfNodesOnB, 1:Indices_1])), New_node_indices];
            end
        elseif Indices_1+NumOfNodesOnB-Indices_2==1
            % add on new nodes on the segment
            Segment2Cut_indices = cellNode_indices(cellNode_onBoundary_indices([Indices_1,Indices_2]));
            New_node = mean(Y(Segment2Cut_indices,:));
            New_node_indices = dsearchn(Y,New_node);
            Node1sharedwith = Yc{Segment2Cut_indices(1)};
            Node2sharedwith = Yc{Segment2Cut_indices(2)};
            whichCellisSegmentShared = intersect(Node1sharedwith,Node2sharedwith);
            for j=1:length(whichCellisSegmentShared)%if shared with other cells
                Cy{whichCellisSegmentShared(j)} = unique([Cy{whichCellisSegmentShared(j)},New_node_indices]);
            end
            % deal with the other side
            SharedIndices1 = floor((Indices_1+Indices_2)/2);
            NewCell_1_indices = [New_node_indices, cellNode_indices(cellNode_onBoundary_indices(Indices_1:SharedIndices1))];
            NewCell_2_indices = [cellNode_indices(cellNode_onBoundary_indices(SharedIndices1:Indices_2)), New_node_indices];
        else
            SharedIndices1 = floor((Indices_1+Indices_2)/2);
            SharedIndices2 = floor((Indices_1+Indices_2+NumOfNodesOnB)/2);
            if SharedIndices2>NumOfNodesOnB
                SharedIndices2 = SharedIndices2 - NumOfNodesOnB;
            end
            temp = [SharedIndices1, SharedIndices2];
            SharedIndices1 = min(temp);
            SharedIndices2 = max(temp);
            NewCell_1_indices = cellNode_indices(cellNode_onBoundary_indices(SharedIndices1:SharedIndices2));
            NewCell_2_indices = cellNode_indices(cellNode_onBoundary_indices([SharedIndices2:NumOfNodesOnB, 1:SharedIndices1]));
        end
        N = N+1;
        new_Cy{indices(i)} = NewCell_1_indices;
        new_Cy{N} = NewCell_2_indices;
    end
    if ~isempty(indices)
        new_Cy = refine_cellshape(new_Cy, Y, Target_side_num);
    end
end

