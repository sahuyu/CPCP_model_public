% used in MainLoop_ode.m

function [X_new, Cy_normal] = updateCellCenter(X, Y, Cy, isCellMigratingOut)
% Cy: new cell-col link list
% X: old X coord

N_new = length(Cy);
N_old = length(X(:,1));
X_new = [X; zeros(N_new-N_old,2)];
isCellMigratingOut = [isCellMigratingOut; false(N_new-N_old,1)];
Cy_normal = Cy;

for i=1:N_new
    if ~isCellMigratingOut(i)
        shape = alphaShape(Y(Cy{i},:));
        list_alpha = alphaSpectrum(shape);
        shape.Alpha = list_alpha(1);
        indices = boundaryFacets(shape);
        Cy_normal{i} = Cy{i}(1,indices(:,1));
        shape = polyshape(Y(Cy_normal{i},:));
        [X_new(i,1),X_new(i,2)] = centroid(shape);
    end
end

end

