%%% used in MainLoop_ode.m

function [] = drawingCurve(Para_cell,dir)

cell_activation = -1:0.1:11;

[cell_orientation, cell_protrusion, cell_contraction] = updateCellStatus(cell_activation, Para_cell, false);

plot(cell_activation,cell_orientation,'r',cell_activation,cell_protrusion,'k',cell_activation,cell_contraction,'b');
legend('orientation.','protrusion','contraction')
xlabel('activation')
axis([-1, 11, 0, max(Para_cell(1:3))]);
set(gcf,'color','white');
A=getframe(gcf);
filename = [dir, 'Activation2CellStatus.png'];
imwrite(A.cdata,filename);
close all;


% input_factor = [0:0.05:4]*10^-4;
% cell_activation = zeros(length(input_factor),1);
% cell_activation = updateCellActivation(cell_activation, input_factor, Para_cell(5), false, [], [], 0);
% 
% plot(input_factor,cell_activation,'r');
% legend('activation')
% xlabel('input factor')
% axis([0, max(input_factor), 0, Para_cell(5)]);
% set(gcf,'color','white');
% A=getframe(gcf);
% filename = [dir, 'StiffSensing2Activation.png'];
% imwrite(A.cdata,filename);
% close all;
% 
% 
% [cell_orientation, cell_protrusion, cell_contraction] = updateCellStatus(cell_activation, Para_cell, false);
% 
% plot(input_factor,cell_orientation,'r',input_factor,cell_protrusion,'k',input_factor,cell_contraction,'b');
% legend('orientation.','protrusion','contraction')
% xlabel('input factor')
% axis([0, max(input_factor), 0, max(Para_cell(1:3))]);
% set(gcf,'color','white');
% A=getframe(gcf);
% filename = [dir, 'StiffSensing2CellStatus.png'];
% imwrite(A.cdata,filename);
% close all;

end

