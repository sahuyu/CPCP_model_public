%% transition of cell-collagen and collagen-cell map
% used in MainLoop_ode.m

function [Output] = list_transition(Input,Size_2)
% Cy: N*1 cell indicating the adhesion sites of each cell,
% expressed in indices of Y.
% Yc: M*1 cell showing that certain node on collagen network is linked with
% which cells, expressed in indices of X.
% if input=[Cy,M], output=Yc; if input=[Yc,N], output=Cy

Size_1 = length(Input);
SparseMatrix = sparse(Size_1,Size_2);
for i=1:Size_1
    SparseMatrix(i,Input{i}) = 1;
end
Output = cell(Size_2,1);
for j=1:Size_2
    Output{j} = find(SparseMatrix(:,j)>0)';
end

end

