%% calculate the angle θ in polar coordinate system
% used in CellSeed.m

function [angle] = angle_anti(center, position)
%angle between OA & OB in radial, O:center, A(1,0), B:input
%center: 1*2 double
%position: N*2 double
    a = [1,0];
    N = length(position);
    angle = zeros(N,1);
    for i=1:N
        b = position(i,:)-center;
        angle(i) = atan2((a(1)*b(2)-a(2)*b(1)),dot(a,b));
    end

end

