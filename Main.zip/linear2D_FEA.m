function [Z_displacement, Triangles, output] = linear2D_FEA(Nodes, Z_force, Material, thickness_PA, Flag_output)

    O = length(Nodes(:,1));
    M = length(Z_force(:,1));
    
    %Initialization
    Model = [];
    %Input
    Triangles=delaunay(Nodes(:,1),Nodes(:,2));
    
    %First Constraint
    Constraint = cell(2*(O-M),1);
    for i=1:O-M
        Constraint{2*i-1,1}.DOF=2*M+2*i-1;
        Constraint{2*i-1,1}.U=0; %x axis
        Constraint{2*i,1}.DOF=2*M+2*i;
        Constraint{2*i,1}.U=0;   %y axis
    end

    %External Load
    U_s = zeros(2*(O-M),1);

    Force = cell(2*M,1);
    for i=1:M
        Force{2*i-1}.Magnitude=Z_force(i,1);
        Force{2*i-1}.DOF=2*i-1; %x axis
        Force{2*i}.Magnitude=Z_force(i,2);
        Force{2*i}.DOF=2*i;     %y axis
    end

    Loading_Steps{1}.Force=Force;
    Loading_Steps{1}.U_s=U_s;
    
    %Prepare Model variable for the solver
    for i=1:1:size(Nodes,1)
        Model.Node{i,1}.x=Nodes(i,1);
        Model.Node{i,1}.y=Nodes(i,2);
        Model.Node{i,1}.DOFx=2*i-1;
        Model.Node{i,1}.DOFy=2*i;
    end

    for i=1:1:size(Triangles,1)
        Model.Element{i,1}.Nodes=Triangles(i,:);
        Model.Element{i,1}.Type='cst';
        Model.Element{i,1}.Material=1; 
    end

    Model.Material=Material;
    Model.Thickness=thickness_PA;
    Model.NDOF=2*size(Model.Node,1);
    Model.Constraint=Constraint;

    Model.Analysis_Status.Analyzed=0;

    %Solver
    Job=Run_Job_Linear(Model,Loading_Steps);
    Model = Job{end}.Model;
    
    % update Z position
    Z_displacement = zeros(O,2);
    for i=1:O
        Z_displacement(i,1)=Model.Node{i}.Ux;
        Z_displacement(i,2)=Model.Node{i}.Uy;
    end
    
    output = zeros(length(Triangles),2);
    if Flag_output
    for i=1:length(Triangles)
        ex=Model.Element{i}.Material_State.e(1);
        ey=Model.Element{i}.Material_State.e(2);
        exy=Model.Element{i}.Material_State.e(3);
        e1=(ex+ey)/2+sqrt(((ex-ey)/2)^2+exy^2);
        %e2=(ex+ey)/2-sqrt(((ex-ey)/2)^2+exy^2);

        sx=Model.Element{i}.Material_State.s(1);
        sy=Model.Element{i}.Material_State.s(2);
        sxy=Model.Element{i}.Material_State.s(3);
        s1=(sx+sy)/2+sqrt(((sx-sy)/2)^2+sxy^2);
        s2=(sx+sy)/2-sqrt(((sx-sy)/2)^2+sxy^2);
        %(equivalent stress or vonMises stress)
        se=sqrt(((s1-s2)^2+s1^2+s2^2)/2);
        output(i,1) = e1;
        output(i,2) = se;
%         Triangles(i,:)=Model.Element{i}.Nodes;
    end
    end

end

