%% used in cell_orienting.m

function [list] = find_adjacent_link(x,loop_num,Y,link_num)
% input: x 1*2 coord of the cell center
% loop_num: num of tiers to search the adjacent link
% list: the indices of links in the surrounding area
% node: the indices of nodes in the surrounding area
    node = dsearchn(Y,x);
    list = [];
    for i=1:loop_num
        for j=1:length(node)
            temp_list_1 = find(link_num(:,1)==node(j));
            temp_list_2 = find(link_num(:,2)==node(j));
            node = [node; link_num(temp_list_1,2); link_num(temp_list_2,1)];
            list = [list; temp_list_1; temp_list_2];
        end
        node = unique(node);
        list = unique(list);
    end
end

