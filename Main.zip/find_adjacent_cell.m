%% used in updateCellActivation.m

function [list] = find_adjacent_cell(indices, loop_num, Cy, Yc)
% find the indices of adjacent cell, including itself

list = indices;
for h=1:loop_num
    for i=1:length(indices)
        target_col_nodes = Cy{indices(i)};
        if ~isempty(target_col_nodes)
            for j=1:length(target_col_nodes)
                list = [list, Yc{target_col_nodes(j)}];
            end
        end
    end
    list = unique(list);
    indices = list;
end

end

