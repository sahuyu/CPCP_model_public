%% used in CellSeed.m

function [result] = interpolation_radial(angle)
%angle: N*1 in radial, [-pi, pi]
%find the two angle value with max interval, output the median of them
    angle = sort(angle);
    n = length(angle);
    interval = zeros(n,1);
    if n==1
        result = angle + pi;
        if result>pi
            result = result-2*pi;
        end
    else
        for i=1:n-1
            interval(i)=angle(i+1)-angle(i);
        end
        interval(n) = 2*pi + angle(1) - angle(n);
        [maximum,indices] = max(interval);
        if indices==n
            result = angle(n) + maximum/2;
            if result>pi
                result = result-2*pi;
            end
        else
            result = angle(indices) + maximum/2;
        end
    end
end

