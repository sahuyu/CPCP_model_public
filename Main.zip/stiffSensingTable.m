%% calculate the stiffness sensing signal
% used in MainLoop_ode.m

function stiff_sensing_table = stiffSensingTable(abs_dy, Para, Cy, X, Y, Z, Z0, h0)
%function stiff_sensing_table = stiffSensingTable(abs_dy, Para, Cy, X, Y, link_num, link_com, link_dis, Z, Z0, h0)
% column 1, collagen top layer only
% column 2, Col-PA
% column 0, both

N = length(Cy);
stiff_sensing_table = cell(N,1);

% for i=1:N
%     K = length(Cy{i});
%     stiff_sensing_table{i} = zeros(K,3);
%     for j=1:K
%         indices = Cy{i}(j);
%         adjacent_list1 = link_num(:,1)==indices;
%         adjacent_list2 = link_num(:,2)==indices;
%         adjacent_indices = [link_num(adjacent_list1,2);link_num(adjacent_list2,1)];
%         adjacent_Y = Y(adjacent_indices,:);
%         adjacent_Y_iscom = [link_com(adjacent_list1);link_com(adjacent_list2)];
%         adjacent_Y_dis = [link_dis(adjacent_list1);link_dis(adjacent_list2)];
%         
%         Yy = Y(indices,:);
%         Zy = Z(indices,:);
%         Z0y = Z0(indices,:);
%         Fy = zeros(3,2);
%         for k=1:length(adjacent_indices)
%             temp_vector = adjacent_Y(k) - Yy;
%             temp_dis = norm(temp_vector);
%             if adjacent_Y_iscom(k)
%                 Fy(1,:) = Fy(1,:) + temp_vector.*Para(2).*(temp_dis-adjacent_Y_dis(k))./temp_dis;
%             elseif temp_dis > adjacent_Y_dis(k)
%                 Fy(1,:) = Fy(1,:) + temp_vector.*Para(1).*(temp_dis-adjacent_Y_dis(k))./temp_dis;
%             end
%         end
%         temp_vector = Z(indices,:) - Yy;
%         temp_dis = norm(temp_vector);
%         Fy(2,:) = temp_vector.*Para(1).*(1-h0/sqrt(h0^2+temp_dis^2));
%         Fy(3,:) = Fy(1,:) + Fy(2,:);
%         
%         dy = X(i,:)-Y(indices,:);
%         dy = dy.*abs_dy./norm(dy);
%         Ydy = Y(indices,:) + dy;
%         Fdy = zeros(3,2);
%         for k=1:length(adjacent_indices)
%             temp_vector = adjacent_Y(k) - Ydy;
%             temp_dis = norm(temp_vector);
%             if adjacent_Y_iscom(k)
%                 Fdy(1,:) = Fdy(1,:) + temp_vector.*Para(2).*(temp_dis-adjacent_Y_dis(k))./temp_dis;
%             elseif temp_dis > adjacent_Y_dis(k)
%                 Fdy(1,:) = Fdy(1,:) + temp_vector.*Para(1).*(temp_dis-adjacent_Y_dis(k))./temp_dis;
%             end
%         end
%         estimated_ratio = dot((Yy-Z0y),(Zy-Z0y))./norm((Yy-Z0y));
%         Zdy = Z(indices,:) + dy.*min(1,max(0,estimated_ratio));
%         temp_vector = Zdy - Ydy;
%         temp_dis = norm(temp_vector);
%         Fdy(2,:) = temp_vector.*Para(1).*(1-h0/sqrt(h0^2+temp_dis^2));
%         Fdy(3,:) = Fdy(1,:) + Fdy(2,:);
%         
%         stiff_sensing_table{i}(j,:) = dot((Fy-Fdy),[dy;dy;dy],2)./(abs_dy^2);
%     end
% end

for i=1:N
    K = length(Cy{i});
    stiff_sensing_table{i} = zeros(K,1);
    for j=1:K
        indices = Cy{i}(j);
        Yy = Y(indices,:);
        Zy = Z(indices,:);
        Z0y = Z0(indices,:);
        temp_vector = Zy - Yy;
        temp_dis = norm(temp_vector);
        Fy = temp_vector.*Para(1).*(1-h0/sqrt(h0^2+temp_dis^2));
        
        dy = X(i,:)-Yy;
        dy = dy.*abs_dy./norm(dy);
        Ydy = Y(indices,:) + dy;
        estimated_ratio = dot((Yy-Z0y),(Zy-Z0y))./norm((Yy-Z0y));
        Zdy = Z(indices,:) + dy.*min(1,max(0,estimated_ratio));
        temp_vector = Zdy - Ydy;
        temp_dis = norm(temp_vector);
        Fdy = temp_vector.*Para(1).*(1-h0/sqrt(h0^2+temp_dis^2));
        
        stiff_sensing_table{i}(j,:) = dot((Fy-Fdy),dy,2)./(abs_dy^2);
    end
end

end

