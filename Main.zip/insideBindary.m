%% rectangle (mode=0)
% length: a
% width: b
%% circle (mode=1)
% center: a
% radius: b
%% diagonal (mode=2)
% bottomleft: a
% topright: b

function [flag_in] = insideBindary(x,a,b,mode)
    flag_in = false;
    if mode==0
        flag_in = x(1)>0 & x(1)<a & x(2)>0 & x(2)<b;
    elseif mode==1
        flag_in = dist2(x,a)<=b;
    elseif mode==2
        flag_in = x(1)>a(1) & x(1)<b(1) & x(2)>a(2) & x(2)<b(2);
    end
return