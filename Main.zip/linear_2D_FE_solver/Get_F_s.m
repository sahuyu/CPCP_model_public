function F_s=Get_F_s(F_ex,F_i,Support)

F_s=F_i(Support)-F_ex(Support);

end