%% data analysis and plotting
% cell migration trajectories

DataAndParameters;

LN = readmatrix('output/MaxLoopNumber.txt');
StepLength = 8;
Steps = LN/StepLength;
dt = 75*StepLength/3600; %in hr
min_frame = 12;
X_cell = cell(Steps+1,1);

%% Cell tracking
for t=0:1:Steps

    TargetTime = num2str(t*StepLength,'%04d');
    X_cell{t+1} = readmatrix(['output/X.', TargetTime , '.txt']);

end

N = length(X_cell{Steps});

center = [150,150];
range = 40;
screened_startInx = ones(N,1);
for nStep = 1:Steps
    N_thisStep = length(X_cell{nStep});
    for nCell = 1:N_thisStep
        if dist2(X_cell{nStep}(nCell,:),center)<range
            screened_startInx(nCell) = nStep+1;
        end
    end
    if N>N_thisStep
        screened_startInx(N_thisStep+1:N) = (nStep+1).*ones(N-N_thisStep,1);
    end
end

calc_speed = zeros(Steps,N); %in um/hr
calc_dis = zeros(Steps,N); %in um
calc_persis = zeros(Steps,N);

for nCell=1:N
    if screened_startInx(nCell)<Steps+1
        for nStep = screened_startInx(nCell):Steps
            calc_speed(nStep,nCell) = dist2(X_cell{nStep}(nCell,:),X_cell{nStep+1}(nCell,:))./dt;
            calc_dis(nStep,nCell) = dist2(X_cell{screened_startInx(nCell)}(nCell,:),X_cell{nStep+1}(nCell,:));
            if (nStep-screened_startInx(nCell))>=(min_frame/2) && (Steps-nStep)>=(min_frame/2-1)
                temp_start_step = nStep-round(min_frame/2);
                temp_end_step = nStep+round(min_frame/2)-1;
                net_dis = dist2(X_cell{temp_start_step}(nCell,:),X_cell{temp_end_step}(nCell,:));
                cumulative_dis = 0;
                for i=1:temp_end_step-temp_start_step
                    cumulative_dis = cumulative_dis + dist2(X_cell{temp_start_step+i-1}(nCell,:),X_cell{temp_start_step+i}(nCell,:));
                end
                calc_persis(nStep,nCell) = net_dis/cumulative_dis;
            end
        end
    end
end

calc_speed(calc_speed==0) = NaN;
calc_dis(calc_dis==0) = NaN;
calc_persis(calc_persis==0) = NaN;
analysis_speed = [mean(calc_speed,2,'omitnan'),std(calc_speed,[],2,'omitnan'),sum(calc_speed>0,2)];
analysis_dis = [mean(calc_dis,2,'omitnan'),std(calc_dis,[],2,'omitnan'),sum(calc_dis>0,2)];
analysis_persis = [mean(calc_persis,2,'omitnan'),std(calc_persis,[],2,'omitnan'),sum(calc_persis>0,2)];
if ~isfolder('analysis')
    mkdir('analysis');
end
writematrix([analysis_speed,analysis_dis,analysis_persis],['analysis/Cell_TData_Mean+SD.xlsx'],'Sheet','Data');

%% plot the trajectories colored with velocity
%{
close all;
fig1=figure('Visible','off');
fig1.Colormap=jet;
numBin = 10; %(input('What is number of bins for colormap?'));
c = jet(numBin);
max_velocity = 10;

for nStep = 5:Steps
    N_thisStep = length(X_cell{nStep});
    for nCell = 1:N_thisStep
        plot_x = [X_cell{nStep}(nCell,1),X_cell{nStep+1}(nCell,1)];
        plot_y = [X_cell{nStep}(nCell,2),X_cell{nStep+1}(nCell,2)];
        b = ceil((calc_speed(nStep,nCell)/max_velocity)*numBin);
        if b<1 || isnan(b)
            b = 1;
        end
        if b>numBin
            b = numBin;
        end
        if ~isnan(b)
            plot(plot_x, plot_y, 'color', c(b,:),'LineWidth',1.0,'LineJoin','round');
            hold on
        end
    end
end
hold off

axis equal;
axis([0, L, 0, W]);
dir = 'analysis/Cell_Tracks_Realtime';
print('-painters',dir,'-dpdf'); %PDF
close(fig1);
%}