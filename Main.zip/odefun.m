% used in MainLoop_ode.m

function dxdt = odefun(t, x, data)
% Right-hand side function
M = data.M;
E = data.E;
Y = [x(1:M), x(M+1:2*M)];
Z = data.Z;
h0 = data.h;
maxDis = data.dis;

Para = data.Para;
dxdt = zeros(2*M,1);

% collagen nodes generated
for j=1:E
    s = data.link_num(j,1);
    t = data.link_num(j,2);
    temp_vector = Y(s,:) - Y(t,:);
    temp_dis = norm(temp_vector);
%     if (~data.link_com(j) && temp_dis <= Para(3)*data.link_dis(j))
%         %fprintf('compacted = [ %d, %d ]\n', s, t);
%         data.link_com(j) = true;
%         data.link_dis(j) = Para(3)*data.link_dis(j);
%         write('compacted.temp',j);
%     end
%     if (~data.link_com(j) && temp_dis > data.link_dis(j))
%         temp = Para(1).*(temp_dis-data.link_dis(j))./temp_dis;
%         dxdt(s) = dxdt(s) - temp.*temp_vector(1);
%         dxdt(M+s) = dxdt(M+s) - temp.*temp_vector(2);
%         dxdt(t) = dxdt(t) + temp.*temp_vector(1);
%         dxdt(M+t) = dxdt(M+t) + temp.*temp_vector(2);
%     end
%     if data.link_com(j)
%         temp = Para(2).*(temp_dis-data.link_dis(j))./temp_dis;
%         dxdt(s) = dxdt(s) - temp.*temp_vector(1);
%         dxdt(M+s) = dxdt(M+s) - temp.*temp_vector(2);
%         dxdt(t) = dxdt(t) + temp.*temp_vector(1);
%         dxdt(M+t) = dxdt(M+t) + temp.*temp_vector(2);
%     end
    if data.link_com(j)
        temp = Para(2).*(temp_dis-data.link_dis(j))./temp_dis;
        dxdt(s) = dxdt(s) - temp.*temp_vector(1);
        dxdt(M+s) = dxdt(M+s) - temp.*temp_vector(2);
        dxdt(t) = dxdt(t) + temp.*temp_vector(1);
        dxdt(M+t) = dxdt(M+t) + temp.*temp_vector(2);
    elseif temp_dis > data.link_dis(j)
        temp = Para(1).*(temp_dis-data.link_dis(j))./temp_dis;
        dxdt(s) = dxdt(s) - temp.*temp_vector(1);
        dxdt(M+s) = dxdt(M+s) - temp.*temp_vector(2);
        dxdt(t) = dxdt(t) + temp.*temp_vector(1);
        dxdt(M+t) = dxdt(M+t) + temp.*temp_vector(2);
    end
end

% PA nodes generated
for j=1:M
    temp_vector = Z(j,:) - Y(j,:);
    temp_dis = norm(temp_vector);
    if temp_dis>maxDis
        temp_dis = maxDis;
        temp_vector = temp_vector.*maxDis./temp_dis;
    end
    temp = Para(1).*(1-h0/sqrt(h0^2+temp_dis^2));
    dxdt(j) = dxdt(j) + temp.*temp_vector(1);
    dxdt(M+j) = dxdt(M+j) + temp.*temp_vector(2);
end

return