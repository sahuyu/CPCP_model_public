%% plotting, used for debugging
% plot only one frame

figure('Visible','off');

% cell only
color_step = 20;
color_range = floor(color_step.*cell_stiff_sensing./max(cell_stiff_sensing));
color_map = jet(color_step+1);
for i=1:N
    if ~isCellMigratingOut(i)
        patch('Faces',Cy_normal{i},'Vertices',Y,'EdgeColor',color_map(max(0,color_range(i))+1,:),'FaceColor','none','LineWidth',1);
%         patch(Y(Cy{i},1),Y(Cy{i},2),i);
        hold on
    end
end
colormap jet;
colorbar;%('Ticks',[0:1/color_step:1]);
title(num2str(max(cell_stiff_sensing),'%.10f'))
scatter(X(:,1),X(:,2),'k');

for i=1:N
    plot([X(i,1), X(i,1)+cell_orienting_vector(i,1)],[X(i,2), X(i,2)+cell_orienting_vector(i,2)],'r','LineWidth',1.5);
end

hold off
axis equal;

axis([0, L, 0, W]);
set(gcf,'color','white');
set(gcf,'position',[100,100,1100,900]);
A=getframe(gcf);
imwrite(A.cdata,filename);
% time = round(clock);
% imwrite(A.cdata,['step_',num2str(time(1),'%04d'),num2str(time(2),'%02d'),num2str(time(3),'%02d'),num2str(time(4),'%02d'),num2str(time(5),'%02d'),num2str(time(6),'%02d'),'.png']);
close all;
