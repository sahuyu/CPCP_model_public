%% initialization code
% generate a randomly distributed collagen network

%% rectangle
% unit: um
% length: Ls
% width: W

L = 300;
W = 300;

% nodes on outline
d = 5; %distance of nodes on th edge
P = 2*(L+W)/d;
outline = [[0:d:L-d],   L*ones(1,W/d),[L:-d:d],      zeros(1,W/d);
           zeros(1,L/d),[0:d:W-d],    W*ones(1,L/d),[W:-d:d]]';
       
% density of nodes (nodes/100um^2)
density = 40;
% minimum distance between different nodes
min = 1;
% number of node, beside outline
Q = ceil(density*L*W/100);

% nodes inside
inner = zeros(Q,2);
k = 1;
% random distribution
seed=clock;
seed=round(sum(seed(4:6))*sum(seed(2:3))/10);
rng(seed);
temp = unifrnd (0,L,12*Q,2);

for i=1:12*Q
    [indices,d] = dsearchn(inner,temp(i,:));
    if d>min
        inner(k,:) = temp(i,:);
        k = k+1;
    end
    if k>Q
        break;
    end
end

%{
for i=1:12*Q
    if insideBindary(temp(i,:),L,W,0)
        flag = 1;
        if k>1
            for j=1:k
                if dist2(temp(i,:),inner(j,:))<min
                    flag = 0;
                end
            end
        end
    end
    
    if flag==1
        inner(k,:) = temp(i,:);
        k = k+1;
        flag = 0;
    end
    if k>Q
        break;
    end
end
%}

Y = inner;%[Q], collagen network
Z = [inner ; outline];%[Q;P], PA gel mesh

% scatter(Y(:,1),Y(:,2),'.');

DT = delaunayTriangulation(Y);
triplot(DT);
hold on

M = length(Y);%number of nodes in collagen network
T = DT.size(1);%number of triangles
E = T*3;%number of links (edges)

% link_num: node(i), node(j), collagen network
% link_dis: dis(i,j) (if i<j && node(i) is linked with node(j))
link_num = zeros(E,2);
link_dis = zeros(E,1);

temp = zeros(E+1,2);
ele = DT.ConnectivityList;

for i=1:T
    temp_ele = sort(ele(i,:));
    temp(3*i-2,:) = [temp_ele(1),temp_ele(2)];
    temp(3*i-1,:) = [temp_ele(1),temp_ele(3)];
    temp(3*i,:) = [temp_ele(2),temp_ele(3)];
end
temp = sortrows(temp,[1 2]);

% exclude the marginal nodes
index = 1;
for i=2:E
    if temp(i,1)>temp(i-1,1) || temp(i,2)>temp(i-1,2)
        link_num(index,:) = temp(i,:);
        link_dis(index) = norm([(Y(link_num(index,1),1)-Y(link_num(index,2),1)),(Y(link_num(index,1),2)-Y(link_num(index,2),2))]);
        index = index+1;
    end
end
E = index-1;
link_num = link_num(1:index-1,:);
link_dis = link_dis(1:index-1,:);

% output
fileanme = 'ini.Y.txt';
writematrix(Y,fileanme);
fileanme = 'ini.Z.txt';
writematrix(Z,fileanme);
fileanme = 'ini.linknum.txt';
writematrix(link_num,fileanme);
fileanme = 'ini.linkdis.txt';
writematrix(link_dis,fileanme);
fileanme = 'ini.ele.txt';
writematrix(ele,fileanme);

% for i=1:E
%     s = link_num(i,1);
%     t = link_num(i,2);
%     plot([Y(s,1),Y(t,1)],[Y(s,2),Y(t,2)],'c-');
%     hold on
% end
% hold off
patch('Faces',ele,'Vertices',Y,'EdgeColor','cyan','EdgeAlpha',0.5,'FaceColor','none');
axis([0, L, 0, W]);
axis equal;